/**
 * Clase Temperatura para gestionar valores de temperatura en Celsius
 * Valida que la temperatura no sea inferior a -273.15 (cero absoluto)
 */
public class Temperatura {
    private static final double CERO_ABSOLUTO = -273.15;
    private double celsius;

    /**
     * Constructor por defecto inicializa la temperatura a 0 grados
     */
    public Temperatura() {
        this.celsius = 0.0;
    }

    /**
     * Constructor que inicializa con un valor de temperatura específico
     * 
     * @param celsius valor inicial de temperatura en Celsius
     * @throws IllegalArgumentException si el valor es menor al cero absoluto
     */
    public Temperatura(double celsius) {
        if (celsius < CERO_ABSOLUTO) {
            throw new IllegalArgumentException("La temperatura no puede ser menor a " + CERO_ABSOLUTO + "°C");
        }
        this.celsius = celsius;
    }

    /**
     * Obtiene el valor actual de la temperatura en Celsius
     * 
     * @return temperatura actual en Celsius
     */
    public double obtenerTemperatura() {
        return this.celsius;
    }

    /**
     * Aumenta la temperatura en el valor especificado
     * 
     * @param cantidad cantidad a aumentar (puede ser decimal)
     * @return true si la operación fue exitosa
     */
    public boolean aumentar(double cantidad) {
        if (cantidad < 0) {
            return false;
        }
        this.celsius += cantidad;
        return true;
    }

    /**
     * Disminuye la temperatura en el valor especificado
     * Valida que no se baje del cero absoluto
     * 
     * @param cantidad cantidad a disminuir (puede ser decimal)
     * @return true si la operación fue exitosa, false si se intenta bajar del cero absoluto
     */
    public boolean disminuir(double cantidad) {
        if (cantidad < 0) {
            return false;
        }
        double nuevaTemperatura = this.celsius - cantidad;
        if (nuevaTemperatura < CERO_ABSOLUTO) {
            return false;
        }
        this.celsius = nuevaTemperatura;
        return true;
    }

    /**
     * Establece un nuevo valor de temperatura validando el cero absoluto
     * 
     * @param celsius nuevo valor de temperatura
     * @return true si la operación fue exitosa, false si es menor al cero absoluto
     */
    public boolean establecerTemperatura(double celsius) {
        if (celsius < CERO_ABSOLUTO) {
            return false;
        }
        this.celsius = celsius;
        return true;
    }

    /**
     * Retorna una representación en string de la temperatura actual
     * 
     * @return string con la temperatura formateada
     */
    @Override
    public String toString() {
        return String.format("%.2f°C", this.celsius);
    }
}
