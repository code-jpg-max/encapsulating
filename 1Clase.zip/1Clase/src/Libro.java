public class Libro {
    private String titulo;
    private String autor;
    private int numeroPaginas;

    // Constructor
    public Libro(String titulo, String autor, int numeroPaginas) {
        this.titulo = titulo;
        this.autor = autor;
        this.numeroPaginas = numeroPaginas > 0 ? numeroPaginas : 0;
    }

    // Getters
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    // Setter con validación
    public boolean setNumeroPaginas(int numeroPaginas) {
        if (numeroPaginas > 0) {
            this.numeroPaginas = numeroPaginas;
            return true;
        }
        return false;
    }

    // Método para mostrar información
    public String mostrarInfo() {
        return "Título: " + titulo + "\n" +
               "Autor: " + autor + "\n" +
               "Páginas: " + numeroPaginas;
    }
}
