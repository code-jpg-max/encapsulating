public class MainCuenta {
    public static void main(String[] args) {
        Cuenta c1 = new Cuenta();
        System.out.println(c1.getI());
        Cuenta c2 = new Cuenta();
        System.out.println(c2.getI());
    }
}