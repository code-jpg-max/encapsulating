package com.clase4.vehiculo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * GUI para la aplicación de Vehículo usando Java Swing.
 */
public class VehiculoGUI extends JFrame {
    private JTextField marcaField;
    private JTextField modeloField;
    private JTextField velocidadInicialField;
    private JTextField cambioField;
    private JButton crearButton;
    private JButton acelerarButton;
    private JButton frenarButton;
    private JLabel estadoLabel;
    private Vehiculo vehiculo;

    public VehiculoGUI() {
        setTitle("Aplicación Vehículo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(8, 2));

        // Componentes para crear vehículo
        add(new JLabel("Marca:"));
        marcaField = new JTextField();
        add(marcaField);

        add(new JLabel("Modelo:"));
        modeloField = new JTextField();
        add(modeloField);

        add(new JLabel("Velocidad Inicial:"));
        velocidadInicialField = new JTextField();
        add(velocidadInicialField);

        crearButton = new JButton("Crear Vehículo");
        add(crearButton);
        add(new JLabel()); // Espacio vacío

        // Componentes para acelerar/frenar
        add(new JLabel("Cambio de Velocidad:"));
        cambioField = new JTextField();
        add(cambioField);

        acelerarButton = new JButton("Acelerar");
        add(acelerarButton);
        frenarButton = new JButton("Frenar");
        add(frenarButton);

        // Etiqueta para estado
        add(new JLabel("Estado:"));
        estadoLabel = new JLabel("Vehículo no creado");
        add(estadoLabel);

        // Deshabilitar botones inicialmente
        acelerarButton.setEnabled(false);
        frenarButton.setEnabled(false);

        // Listeners
        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearVehiculo();
            }
        });

        acelerarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambiarVelocidad(true);
            }
        });

        frenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambiarVelocidad(false);
            }
        });
    }

    private void crearVehiculo() {
        try {
            String marca = marcaField.getText().trim();
            String modelo = modeloField.getText().trim();
            int velocidadInicial = Integer.parseInt(velocidadInicialField.getText().trim());

            if (marca.isEmpty() || modelo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Marca y modelo no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            vehiculo = new Vehiculo(marca, modelo, velocidadInicial);
            estadoLabel.setText(vehiculo.mostrarEstado());
            acelerarButton.setEnabled(true);
            frenarButton.setEnabled(true);
            JOptionPane.showMessageDialog(this, "Vehículo creado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Velocidad inicial debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cambiarVelocidad(boolean acelerar) {
        if (vehiculo == null) {
            JOptionPane.showMessageDialog(this, "Cree un vehículo primero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int cambio = Integer.parseInt(cambioField.getText().trim());
            if (cambio <= 0) {
                JOptionPane.showMessageDialog(this, "El cambio debe ser un número positivo.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean exito;
            if (acelerar) {
                exito = vehiculo.acelerar(cambio);
                if (!exito) {
                    JOptionPane.showMessageDialog(this, "No se puede acelerar: velocidad máxima excedida (200 km/h).", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                exito = vehiculo.frenar(cambio);
                if (!exito) {
                    JOptionPane.showMessageDialog(this, "No se puede frenar: velocidad no puede ser negativa.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

            if (exito) {
                estadoLabel.setText(vehiculo.mostrarEstado());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El cambio debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VehiculoGUI().setVisible(true);
        });
    }
}