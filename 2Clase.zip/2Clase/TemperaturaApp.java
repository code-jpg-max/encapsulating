import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Interfaz gráfica para la aplicación Temperatura
 * Permite aumentar, disminuir y establecer valores de temperatura con validación
 */
public class TemperaturaApp extends JFrame {
    private Temperatura temperatura;
    private JTextField campoCelsius;
    private JLabel etiquetaTemperatura;
    private JLabel etiquetaError;
    private JButton botonAumentar;
    private JButton botonDisminuir;
    private JButton botonEstablecer;
    private JSpinner spinnerCantidad;

    public TemperaturaApp() {
        // Configuración de la ventana principal
        setTitle("Gestor de Temperatura");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setResizable(false);

        // Crear instancia de temperatura
        temperatura = new Temperatura();

        // Crear componentes
        crearComponentes();
    }

    private void crearComponentes() {
        // Panel principal
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Panel superior - Mostrar temperatura actual
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BorderLayout());
        panelSuperior.setBorder(BorderFactory.createTitledBorder("Temperatura Actual"));

        etiquetaTemperatura = new JLabel("0.00°C");
        etiquetaTemperatura.setFont(new Font("Arial", Font.BOLD, 28));
        etiquetaTemperatura.setHorizontalAlignment(SwingConstants.CENTER);
        etiquetaTemperatura.setForeground(new Color(0, 102, 204));
        panelSuperior.add(etiquetaTemperatura, BorderLayout.CENTER);

        // Panel central - Opciones de modificación
        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new GridLayout(4, 2, 10, 10));
        panelCentral.setBorder(BorderFactory.createTitledBorder("Modificar Temperatura"));

        // Etiqueta y spinner para cantidad
        JLabel etiquetaCantidad = new JLabel("Cantidad (°C):");
        spinnerCantidad = new JSpinner(new SpinnerNumberModel(1.0, 0.0, 1000.0, 0.5));
        JSpinner.NumberEditor editor = (JSpinner.NumberEditor) spinnerCantidad.getEditor();
        JFormattedTextField ftf = editor.getTextField();
        ftf.setColumns(10);

        // Etiqueta y campo de entrada
        JLabel etiquetaEntrada = new JLabel("Estabelecer Temperatura:");
        campoCelsius = new JTextField();
        campoCelsius.setHorizontalAlignment(JTextField.CENTER);

        // Botones
        botonAumentar = new JButton("Aumentar");
        botonAumentar.setBackground(new Color(76, 175, 80));
        botonAumentar.setForeground(Color.WHITE);
        botonAumentar.setFocusPainted(false);
        botonAumentar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aumentarTemperatura();
            }
        });

        botonDisminuir = new JButton("Disminuir");
        botonDisminuir.setBackground(new Color(244, 67, 54));
        botonDisminuir.setForeground(Color.WHITE);
        botonDisminuir.setFocusPainted(false);
        botonDisminuir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                disminuirTemperatura();
            }
        });

        botonEstablecer = new JButton("Establecer");
        botonEstablecer.setBackground(new Color(33, 150, 243));
        botonEstablecer.setForeground(Color.WHITE);
        botonEstablecer.setFocusPainted(false);
        botonEstablecer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                establecerTemperatura();
            }
        });

        // Agregar componentes al panel central
        panelCentral.add(etiquetaCantidad);
        panelCentral.add(spinnerCantidad);
        panelCentral.add(botonAumentar);
        panelCentral.add(botonDisminuir);
        panelCentral.add(etiquetaEntrada);
        panelCentral.add(campoCelsius);
        panelCentral.add(botonEstablecer);

        // Panel inferior - Mostrar errores
        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new BorderLayout());
        panelInferior.setBorder(BorderFactory.createTitledBorder("Estado"));

        etiquetaError = new JLabel("Listo");
        etiquetaError.setFont(new Font("Arial", Font.PLAIN, 12));
        etiquetaError.setForeground(new Color(76, 175, 80));
        panelInferior.add(etiquetaError, BorderLayout.CENTER);

        // Agregar paneles al panel principal
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(panelCentral, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        // Agregar panel principal a la ventana
        add(panelPrincipal);
    }

    private void aumentarTemperatura() {
        try {
            double cantidad = (double) spinnerCantidad.getValue();
            if (cantidad < 0) {
                mostrarError("La cantidad no puede ser negativa");
                return;
            }
            if (temperatura.aumentar(cantidad)) {
                actualizarPantalla();
                mostrarExito("Temperatura aumentada en " + cantidad + "°C");
            } else {
                mostrarError("Error al aumentar la temperatura");
            }
        } catch (NumberFormatException e) {
            mostrarError("Ingrese una cantidad válida");
        }
    }

    private void disminuirTemperatura() {
        try {
            double cantidad = (double) spinnerCantidad.getValue();
            if (cantidad < 0) {
                mostrarError("La cantidad no puede ser negativa");
                return;
            }
            if (temperatura.disminuir(cantidad)) {
                actualizarPantalla();
                mostrarExito("Temperatura disminuida en " + cantidad + "°C");
            } else {
                mostrarError("¡Error! No puede bajar del cero absoluto (-273.15°C)");
            }
        } catch (NumberFormatException e) {
            mostrarError("Ingrese una cantidad válida");
        }
    }

    private void establecerTemperatura() {
        try {
            String valor = campoCelsius.getText().trim();
            if (valor.isEmpty()) {
                mostrarError("Ingrese una temperatura");
                return;
            }
            double celsius = Double.parseDouble(valor);
            if (temperatura.establecerTemperatura(celsius)) {
                campoCelsius.setText("");
                actualizarPantalla();
                mostrarExito("Temperatura establecida a " + String.format("%.2f", celsius) + "°C");
            } else {
                mostrarError("¡Error! No puede establecer una temperatura menor a -273.15°C (cero absoluto)");
                campoCelsius.setText("");
            }
        } catch (NumberFormatException e) {
            mostrarError("Ingrese un valor numérico válido");
            campoCelsius.setText("");
        }
    }

    private void actualizarPantalla() {
        etiquetaTemperatura.setText(String.format("%.2f°C", temperatura.obtenerTemperatura()));
    }

    private void mostrarExito(String mensaje) {
        etiquetaError.setText(mensaje);
        etiquetaError.setForeground(new Color(76, 175, 80));
    }

    private void mostrarError(String mensaje) {
        etiquetaError.setText(mensaje);
        etiquetaError.setForeground(new Color(244, 67, 54));
    }

    /**
     * Método principal para iniciar la aplicación
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TemperaturaApp app = new TemperaturaApp();
                app.setVisible(true);
            }
        });
    }
}
