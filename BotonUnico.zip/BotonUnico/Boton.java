import java.awt.event.*;
import javax.swing.*;

public class Boton extends JFrame implements ActionListener {
    private JLabel label1;
    private JLabel label2;
    private JButton boton1;
    public Boton() {
        setLayout(null);
        label1 = new JLabel("Programación orientada a objetos.");
        label1.setBounds(10, 10, 200, 20);
        add(label1);

        label2 = new JLabel("Integrante solitario.");
        label2.setBounds(10, 40, 200, 20);
        add(label2);

        boton1 = new JButton("1");
        boton1.setBounds(10, 70, 200, 30);
        add(boton1);
        boton1.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(200, 150);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            JOptionPane.showMessageDialog(this, "Sebastián Ruiz Muñoz.");
        }
    }

    public static void main(String[] args) {
        Boton boton = new Boton();
        boton.setBounds(0, 0, 300, 200);
        boton.setVisible(true);
        boton.setResizable(false);
        boton.setLocationRelativeTo(null);
    }
}