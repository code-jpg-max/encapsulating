public class Operacion {
    void Operacion() {
        double x = 11;
        System.out.println("Ejemplo: " + 1 / x + ".");
    }
}