package com.clase4.vehiculo;

/**
 * Clase que representa un vehículo con marca, modelo y velocidad.
 */
public class Vehiculo {
    private String marca;
    private String modelo;
    private int velocidad;
    private static final int MAX_VELOCIDAD = 200;

    /**
     * Constructor para crear un vehículo.
     * @param marca La marca del vehículo.
     * @param modelo El modelo del vehículo.
     * @param velocidadInicial La velocidad inicial.
     */
    public Vehiculo(String marca, String modelo, int velocidadInicial) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = velocidadInicial;
    }

    /**
     * Acelera el vehículo por el incremento dado, sin exceder el límite máximo.
     * @param incremento El incremento de velocidad.
     * @return true si se pudo acelerar, false si excede el límite.
     */
    public boolean acelerar(int incremento) {
        if (velocidad + incremento > MAX_VELOCIDAD) {
            return false;
        }
        velocidad += incremento;
        return true;
    }

    /**
     * Frena el vehículo por el decremento dado, sin bajar de 0.
     * @param decremento El decremento de velocidad.
     * @return true si se pudo frenar, false si bajaría de 0.
     */
    public boolean frenar(int decremento) {
        if (velocidad - decremento < 0) {
            return false;
        }
        velocidad -= decremento;
        return true;
    }

    /**
     * Muestra el estado actual del vehículo.
     * @return Una cadena con la marca, modelo y velocidad.
     */
    public String mostrarEstado() {
        return "Marca: " + marca + ", Modelo: " + modelo + ", Velocidad: " + velocidad + " km/h";
    }

    // Getters si necesarios
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getVelocidad() {
        return velocidad;
    }
}