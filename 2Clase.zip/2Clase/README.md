# Aplicación Gestor de Temperatura - Java Swing

## Descripción
Aplicación gráfica en Java que permite gestionar valores de temperatura en Celsius con validaciones automáticas. Incluye una clase `Temperatura` con métodos para aumentar, disminuir y establecer valores, validando que nunca se baje del cero absoluto (-273.15°C).

## Archivos
- **Temperatura.java** - Clase que contiene la lógica de temperatura
- **TemperaturaApp.java** - Interfaz gráfica con Swing

## Características

### Clase Temperatura
- ✓ Atributo privado `celsius`
- ✓ Validación del cero absoluto (-273.15°C)
- ✓ Método `aumentar(double cantidad)` - Incrementa la temperatura
- ✓ Método `disminuir(double cantidad)` - Decrementa la temperatura validando límite
- ✓ Método `obtenerTemperatura()` - Retorna el valor actual
- ✓ Método `establecerTemperatura(double celsius)` - Establece un nuevo valor
- ✓ Constructor con inicialización

### Interfaz Gráfica
- Campo para visualizar temperatura actual (en grande y claro)
- Campo de entrada para establecer temperatura directamente
- Spinner para seleccionar cantidad a aumentar/disminuir
- Botón "Aumentar" (verde) - Incrementa la temperatura
- Botón "Disminuir" (rojo) - Decrementa la temperatura
- Botón "Establecer" (azul) - Establece un nuevo valor
- Panel de estado que muestra mensajes de éxito o error
- Validación con error cuando se intenta bajar del cero absoluto

## Instrucciones de Compilación

Desde la carpeta del proyecto:

```bash
javac Temperatura.java
javac TemperaturaApp.java
```

## Instrucciones de Ejecución

```bash
java TemperaturaApp
```

## Validaciones Implementadas

1. **Cero Absoluto**: No permite establecer temperaturas menores a -273.15°C
2. **Campo Numérico**: Valida que los valores ingresados sean numéricos válidos
3. **Cantidad Negativa**: No acepta cantidades negativas para aumentar/disminuir
4. **Mensajes Descriptivos**: Muestra mensajes de error y éxito en la interfaz

## Ejemplo de Uso

1. Iniciar la aplicación
2. Usar el spinner para seleccionar cantidad (ej: 5.0°C)
3. Click en "Aumentar" para elevar la temperatura
4. Click en "Disminuir" para bajar la temperatura (si es mayor que -273.15°C)
5. O ingresar un valor en el campo de entrada y click en "Establecer"
6. Si intenta bajar del cero absoluto, verá un mensaje de error

## Requisitos

- Java 8 o superior
- Swing (incluido en Java estándar)

---

Desarrollado como ejercicio de Java Swing y POO (Programación Orientada a Objetos)
