# Project Guidelines

## Code Style
Follow standard Java coding conventions. Use camelCase for variables and methods, PascalCase for classes and interfaces. Indent with 4 spaces.

## Architecture
This is a new Java project workspace for class exercises. Structure the code with packages under `src/main/java` and tests under `src/test/java` if using Maven.

## Build and Test
Use Maven for build management. Commands:
- `mvn clean compile` to compile
- `mvn test` to run tests
- `mvn package` to build JAR

Agents will attempt to run these commands automatically.

## Conventions
- Use meaningful variable and method names.
- Add Javadoc comments for public classes and methods.
- Handle exceptions appropriately.