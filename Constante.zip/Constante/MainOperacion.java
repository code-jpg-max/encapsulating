public class MainOperacion {
    public static void main(String[] args) {
        Operacion op = new Operacion();
        op.Operacion(); // Si se llamara directamente a la variable local 'x' marcaría error, ya que no es accesible fuera del método 'Operacion()'.
    }
}