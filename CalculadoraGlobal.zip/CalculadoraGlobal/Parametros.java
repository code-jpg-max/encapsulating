public class Parametros {
    int valor;
    public Parametros(int sumando) {
        this.valor += sumando;
    }
    public int getValor() {
        return valor;
    }
}