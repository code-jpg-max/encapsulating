public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public void actualizarPrecio(double nuevoPrecio) {
        if (nuevoPrecio >= 0) {
            this.precio = nuevoPrecio;
        } else {
            throw new IllegalArgumentException("Precio debe ser >= 0");
        }
    }

    public String mostrarInfo() {
        return "Nombre: " + nombre + ", Precio: " + precio + ", Cantidad: " + cantidad;
    }
}