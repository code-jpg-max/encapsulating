import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LibroGUI extends JFrame {
    private Libro libro;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JTextField txtPaginas;
    private JTextArea txtInfo;
    private JLabel lblMensaje;

    public LibroGUI() {
        setTitle("Gestor de Libros");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setResizable(false);

        // Crear panel principal
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de entrada de datos
        JPanel panelEntrada = new JPanel();
        panelEntrada.setLayout(new GridLayout(3, 2, 5, 5));
        panelEntrada.setBorder(BorderFactory.createTitledBorder("Datos del Libro"));

        panelEntrada.add(new JLabel("Título:"));
        txtTitulo = new JTextField();
        panelEntrada.add(txtTitulo);

        panelEntrada.add(new JLabel("Autor:"));
        txtAutor = new JTextField();
        panelEntrada.add(txtAutor);

        panelEntrada.add(new JLabel("Número de Páginas:"));
        txtPaginas = new JTextField();
        panelEntrada.add(txtPaginas);

        // Panel de información
        JPanel panelInfo = new JPanel();
        panelInfo.setLayout(new BorderLayout());
        panelInfo.setBorder(BorderFactory.createTitledBorder("Información del Libro"));
        txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(txtInfo);
        panelInfo.add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));

        JButton btnCrear = new JButton("Crear Libro");
        btnCrear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearLibro();
            }
        });
        panelBotones.add(btnCrear);

        JButton btnMostrar = new JButton("Mostrar Datos");
        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDatos();
            }
        });
        panelBotones.add(btnMostrar);

        JButton btnActualizar = new JButton("Actualizar Páginas");
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarPaginas();
            }
        });
        panelBotones.add(btnActualizar);

        // Panel de mensaje de error
        JPanel panelMensaje = new JPanel();
        panelMensaje.setLayout(new BorderLayout());
        lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.RED);
        lblMensaje.setFont(new Font("Arial", Font.BOLD, 11));
        panelMensaje.add(lblMensaje, BorderLayout.CENTER);

        // Agregar paneles al panel principal
        panelPrincipal.add(panelEntrada, BorderLayout.NORTH);
        panelPrincipal.add(panelInfo, BorderLayout.CENTER);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // Panel con mensaje de error y botones
        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new BorderLayout());
        panelInferior.add(panelMensaje, BorderLayout.NORTH);
        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.remove(panelBotones);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private void crearLibro() {
        String titulo = txtTitulo.getText().trim();
        String autor = txtAutor.getText().trim();
        String paginasStr = txtPaginas.getText().trim();

        lblMensaje.setText("");

        if (titulo.isEmpty() || autor.isEmpty() || paginasStr.isEmpty()) {
            lblMensaje.setText("Error: Todos los campos deben estar llenos");
            return;
        }

        try {
            int paginas = Integer.parseInt(paginasStr);
            if (paginas <= 0) {
                lblMensaje.setText("Error: El número de páginas debe ser mayor a 0");
                return;
            }
            libro = new Libro(titulo, autor, paginas);
            lblMensaje.setText("Libro creado exitosamente");
            mostrarDatos();
        } catch (NumberFormatException ex) {
            lblMensaje.setText("Error: El número de páginas debe ser un número válido");
        }
    }

    private void mostrarDatos() {
        if (libro == null) {
            lblMensaje.setText("Error: Primero debe crear un libro");
            txtInfo.setText("");
            return;
        }
        txtInfo.setText(libro.mostrarInfo());
        lblMensaje.setText("");
    }

    private void actualizarPaginas() {
        if (libro == null) {
            lblMensaje.setText("Error: Primero debe crear un libro");
            return;
        }

        String paginasStr = JOptionPane.showInputDialog(this, 
            "Ingrese el nuevo número de páginas:", libro.getNumeroPaginas());

        if (paginasStr == null) {
            return;
        }

        try {
            int paginas = Integer.parseInt(paginasStr);
            if (libro.setNumeroPaginas(paginas)) {
                lblMensaje.setText("Páginas actualizadas exitosamente");
                mostrarDatos();
            } else {
                lblMensaje.setText("Error: El número de páginas debe ser mayor a 0");
            }
        } catch (NumberFormatException ex) {
            lblMensaje.setText("Error: Ingrese un número válido");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LibroGUI frame = new LibroGUI();
                frame.setVisible(true);
            }
        });
    }
}
