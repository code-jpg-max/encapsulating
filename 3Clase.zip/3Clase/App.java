import java.awt.*;
import javax.swing.*;

public class App {
    private static Producto producto;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Producto App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField();

        JLabel lblPrecio = new JLabel("Precio:");
        JTextField txtPrecio = new JTextField();

        JLabel lblCantidad = new JLabel("Cantidad:");
        JTextField txtCantidad = new JTextField();

        JButton btnCrear = new JButton("Crear Producto");

        JButton btnMostrar = new JButton("Mostrar Datos");
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);

        JLabel lblNuevoPrecio = new JLabel("Nuevo Precio:");
        JTextField txtNuevoPrecio = new JTextField();

        JButton btnActualizar = new JButton("Actualizar Precio");

        panel.add(lblNombre);
        panel.add(txtNombre);
        panel.add(lblPrecio);
        panel.add(txtPrecio);
        panel.add(lblCantidad);
        panel.add(txtCantidad);
        panel.add(btnCrear);
        panel.add(new JLabel()); // empty
        panel.add(btnMostrar);
        panel.add(txtInfo);
        panel.add(lblNuevoPrecio);
        panel.add(txtNuevoPrecio);
        panel.add(btnActualizar);
        panel.add(new JLabel()); // empty

        frame.add(panel);

        btnCrear.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                int cantidad = Integer.parseInt(txtCantidad.getText());
                producto = new Producto(nombre, precio, cantidad);
                JOptionPane.showMessageDialog(frame, "Producto creado");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Error en formato de numero");
            }
        });

        btnMostrar.addActionListener(e -> {
            if (producto != null) {
                txtInfo.setText(producto.mostrarInfo());
            } else {
                JOptionPane.showMessageDialog(frame, "Crea un producto primero");
            }
        });

        btnActualizar.addActionListener(e -> {
            if (producto != null) {
                try {
                    double nuevoPrecio = Double.parseDouble(txtNuevoPrecio.getText());
                    producto.actualizarPrecio(nuevoPrecio);
                    JOptionPane.showMessageDialog(frame, "Precio actualizado");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Error en formato de numero");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(frame, ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Crea un producto primero");
            }
        });

        frame.setVisible(true);
    }
}