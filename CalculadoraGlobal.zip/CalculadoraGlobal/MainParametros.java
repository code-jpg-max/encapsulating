import java.util.Scanner;
public class MainParametros {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese un numero: ");
            int sumando = scanner.nextInt();
            Parametros parametros = new Parametros(sumando);
            System.out.println("La suma es: " + parametros.getValor());
            Parametros parametros2 = new Parametros(sumando);
            System.out.println("La suma es: " + parametros2.getValor());
        }
    }
}