public class Variables {
    static int x; // Variable estática
    int y; // Variable global
    void method() {
        int z = 10; // Variable local
        System.out.println("Variable local 'z': " + z);
    }
}