public class Cuenta {
    static int i;
    public Cuenta() {
        i++;
    }
    public int getI() {
        return i;
    }
}