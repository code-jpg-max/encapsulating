public class MainVariables {
    public static void main(String[] args) {
        Variables var = new Variables();
        System.out.println("Variable estatica 'x': " + Variables.x); // Acceso a variable estática
        System.out.println("Variable global 'y': " + var.y); // Acceso a variable global
        var.method(); // Llamada al método que contiene la variable local
    }
}